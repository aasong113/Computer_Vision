# Author: Anthony Song

import cv2
import numpy as np

def DrawPolygon( p ):

    points = p

    #create a white image. 
    img = np.zeros((500,500,3), dtype=np.uint8)
    img.fill(255)
    
    
    # create an array to plot the points
    plot_points = np.zeros(( len(points),2), dtype=np.double)
    

    # put points into the array to plot.
    for i in range(len(points)):
        x = points[0][i]
        y = points[1][i]

        
        plot_points[i][0]=x
        plot_points[i][1]=y
    
    # scale back
    points = points*300
    #print(points)
    
    
    # Polygon corner points coordinates
    pts = np.array([[points[0][0], points[1][0]], [points[0][1], points[1][1]],
                [points[0][2], points[1][2]], [points[0][3], points[1][3]]],
               np.int32)

    # reshape for the polyline
    pts = pts.reshape((-1, 1, 2))
  
    isClosed = True
  
    # Black color in BGR
    color = (0, 0, 0)
  
    # Line thickness of 2 px
    thickness = 2
  
    # Using cv2.polylines() method
    # Draw a Black square with
    # thickness of 1 px
    square = cv2.polylines(img, [pts],
                      isClosed, color, thickness)
    
    cv2.imshow('square', square)
    
    cv2.waitKey(0)
    cv2.destroyAllWindows()
    
    

