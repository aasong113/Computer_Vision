#Author: Anthony Song

# We assume that the points are picked either clockwise or counter clockwise.
from DrawPolygon import DrawPolygon
import cv2
import numpy as np

def ProjectiveRectification( pp ):

    points = pp
    # points defined as [x, y, z]
    p_1 = [points[0][0], points[1][0], points[2][0]]
    p_2 = [points[0][1], points[1][1], points[2][1]]
    p_3 = [points[0][2], points[1][2], points[2][2]]
    p_4 = [points[0][3], points[1][3], points[2][3]]
    
    # get the parallel lines
    l_1 = np.cross(p_1,p_2)
    l_2 = np.cross(p_2, p_3)
    l_3 = np.cross(p_3, p_4)
    l_4 = np.cross(p_4, p_1)

    #normalize the points at infinity.
    inf_p_1 = np.cross(l_1, l_3)
    max_p_1 = -10000000
    for i in range(len(inf_p_1)):
        if inf_p_1[i] != 0:
            if max_p_1 < (1/inf_p_1[i]):
                max_p_1 = (1/inf_p_1[i])
                
    inf_p_1 = inf_p_1 / inf_p_1[2]
    #print("infinity point 1")
    #print(inf_p_1)

    inf_p_2 = np.cross(l_2, l_4)
    max_p_2 = -100000000
    for i in range(len(inf_p_2)):
        if inf_p_2[i] != 0:
            if max_p_2 < (1/inf_p_2[i]):
                max_p_2 = (1/inf_p_2[i])
    
    inf_p_2 = inf_p_2 / inf_p_2[2]
    #print("infinity point 2")
    #print(inf_p_2)

    infinity_line = np.cross(inf_p_1,inf_p_2)
    
    # Calculate H_p homgoraphy matrix.
    h_p = np.array([[1,0,0],[0,1,0], infinity_line], np.double)
    
    
    # calculate the rectified coordinates
    p = points
    for i in range(len(p[0])):
        x_1 = (h_p[0][0]*p[0][i]+h_p[0][1]*p[1][i]+h_p[0][2])
        
        x_2 = (h_p[1][0]*p[0][i]+h_p[1][1]*p[1][i]+h_p[1][2])
        
        x_3 = (h_p[2][0]*p[0][i]+h_p[2][1]*p[1][i]+h_p[2][2])
    
        x_prime = x_1/x_3
        p[0][i] = x_prime
        
        y_prime = x_2/x_3
        p[1][i] = y_prime
        
    

    #display the rectified coordinates
    DrawPolygon(abs(p))
    
    
    
    
    
    #return homography. 
    return h_p
    
 
    
    

