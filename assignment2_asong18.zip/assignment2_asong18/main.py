# Author: Anthony Song

import numpy as np
from PointPicker import PointPicker
from ProjectiveDistortion import ProjectiveDistortion
from DrawPolygon import DrawPolygon
from ProjectiveRectification import ProjectiveRectification
from OpenCVRectification import OpenCVRectification

def main():
    
    #/Users/xzhao/Desktop/z_Computer_Vision/HW_2/assignment2
    
    #assuming the image is in the current working directory.
    image_path = 'dots.jpg';
    
    # pick points form image.
    # Scaled points are rounded for the sake of simplicity.
    scaled_points = PointPicker()

    # point to store the coordinates.
    #test = np.array([[0, 1, 1, 0],[0, 0, 1, 1],[1,1,1,1]], np.double)
    #test
    #distorted_points = ProjectiveDistortion(test)
    
    # make a copy for OpenCVRectification
    scaled_points_1 = np.copy(scaled_points)
    
    
    #Distort mouse clicked points.
    distorted_points = ProjectiveDistortion(scaled_points)
    
    #Draw Polygon square
    DrawPolygon(distorted_points)
    
    # copy for OpenCVRectification
    distorted_points_1 = np.copy(distorted_points)
    
    # calculate and display rectified. 
    homography_p = ProjectiveRectification(distorted_points)
    

    
    print()
    print("homography p (h_p)")
    print(homography_p)
    print()
    
    # call open cv to display the recitified shape.
    og_homography = OpenCVRectification( scaled_points_1, distorted_points_1  )
    
    #og_homography = OpenCVRectification( test, dp_test  )
    print()
    print("Original Distortion Matrix (h)")
    print(og_homography)
    
if __name__=="__main__":
    main()
