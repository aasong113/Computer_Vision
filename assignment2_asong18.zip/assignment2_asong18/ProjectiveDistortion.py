#Author: Anthony Song

import cv2
import numpy as np

def ProjectiveDistortion( ph ):

    p = ph
    # create homography
    h = np.zeros((3,3),np.double)
    h[0][0]=1
    h[1][1]=1
    h[2][2]=1
    h[2][0]=1
    h[2][1]=1
    
    columns = len(p[0])

    
    for i in range(columns):
        x_1 = (h[0][0]*p[0][i]+h[0][1]*p[1][i]+h[0][2])
        
        x_2 = (h[1][0]*p[0][i]+h[1][1]*p[1][i]+h[1][2])
        
        x_3 = (h[2][0]*p[0][i]+h[2][1]*p[1][i]+h[2][2])
    
        x_prime = x_1/x_3
        p[0][i] = x_prime
    
        y_prime = x_2/x_3
        p[1][i] = y_prime
        
        
        
   
    
    return p

