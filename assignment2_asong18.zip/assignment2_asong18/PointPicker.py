# Author: Anthony Song
# Good 9/22

import cv2
import numpy as np
# The function PointPicker has no input but must return a numpy.ndarray of size 3xN (an array of homogeneous coordinates) where N is the number of selected points (we will use N=4).


# point to store the coordinates.
scaled_points = np.zeros((3,4),np.double)

#counter to store the number of clicks.
counter = 0

# used to capture the left clicks.
def mouseClick(event, x,y, flags, params):
    
    global scaled_points,counter
    # detects left mouse click and stores those points.
    if event == cv2.EVENT_LBUTTONDOWN:
        
        # x coordinate, row 1
        scaled_points[0][counter]=round(x/300)

        # y coordinate, row 2
        scaled_points[1][counter]=round(y/300)

        # z coordinate, row 3
        scaled_points[2][counter]=1

        
        counter = counter+1
        print("Selected point " + str(counter))
        #print(points)
        

def PointPicker():
    
    global scaled_points, counter
    
    # specify the number of points in this case we use 4.
    number_points = 4;
    
    #assuming the image is in the current working directory.
    image_path = 'dots.jpg';
    img = cv2.imread(image_path,0)
    #img = cv2.imread('dots.jpg',0)
    #print(img)
  
    cv2.imshow('image', img)
    
    #While loop tracks when 4 clicks have been made.
    while True:
        cv2.setMouseCallback('image', mouseClick)
        
        cv2.waitKey(1)
    
        if counter == number_points:
            print('done selecting points')
            break
    
    cv2.destroyAllWindows()
    
    return scaled_points
    



