# Author: Anthony Song

import cv2
import numpy as np

def OpenCVRectification( p, pp  ):

    #rename
    undistorted = p
    distorted = pp
    

    
    #create reshaped matrix for cv2.findHomography
    undistorted_reshaped = np.zeros((4,2),np.double)
    distorted_reshaped = np.zeros((4,2),np.double)
    
    for i in range(len(p[0])):
        undistorted_reshaped[i][0] = undistorted[0][i]
        undistorted_reshaped[i][1] = undistorted[1][i]
        
        distorted_reshaped[i][0] = distorted[0][i]
        distorted_reshaped[i][1] = distorted[1][i]
    
    #find homography original (distortion matrix)
    h, status = cv2.findHomography(undistorted_reshaped, distorted_reshaped)

    #round numbers and return, should be same as the original distortion matrix.
    h = np.round(h)

    return h
